package com.azhar.mylyrics.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.azhar.mylyrics.R
import com.google.android.material.bottomnavigation.BottomNavigationView

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)


        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottomNavigation)
        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_home -> {
                    val intent = Intent(this@AboutActivity, MainActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.menu_search -> {
                    val intent = Intent(this@AboutActivity, SearchActivity::class.java)
                    startActivity(intent)
                    true
                }


                else -> {
                    bottomNavigation.menu.findItem(R.id.menu_about)?.isChecked = true
                    // Add additional logic related to the search action if needed
                    true
                }
                // Lakukan inisialisasi atau tampilkan konten halaman pencarian di sini
            }
        }
    }
}