package com.azhar.mylyrics.activities

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.azhar.mylyrics.R
import com.azhar.mylyrics.adapter.MainAdapter
import com.azhar.mylyrics.model.ModelMain
import com.azhar.mylyrics.networking.ApiEndpoint
import com.azhar.mylyrics.utils.OnItemClickCallback
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_search.*
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class SearchActivity : AppCompatActivity() {

    var modelMainList = ArrayList<ModelMain>()
    var mainAdapter: MainAdapter? = null
    var progressDialog: ProgressDialog? = null
    private lateinit var navigation: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        // Lakukan inisialisasi atau tampilkan konten halaman pencarian di sini

            progressDialog = ProgressDialog(this)
            progressDialog?.setTitle("Mohon Tunggu")
            progressDialog?.setCancelable(false)
            progressDialog?.setMessage("Sedang menampilkan hasil pencarian...")

            rvListMusic.layoutManager = LinearLayoutManager(this)
            rvListMusic.setHasFixedSize(true)

            // Gunakan SearchView yang sesuai di layout activity_search.xml
            val searchView = findViewById<SearchView>(R.id.searchSong)




        fun showRecyclerSearchResults() {
            mainAdapter = MainAdapter(this, modelMainList)
            rvListMusic.adapter = mainAdapter
            mainAdapter?.setOnItemClickCallback(object : OnItemClickCallback {
                override fun onItemClicked(modelMain: ModelMain) {
                    val intent = Intent(this@SearchActivity, DetailLyricsActivity::class.java)
                    intent.putExtra(DetailLyricsActivity.LIST_LYRICS, modelMain)
                    startActivity(intent)
                }
            })
        }

        fun setSearchSong(query: String) {
            progressDialog?.show()
            AndroidNetworking.get(ApiEndpoint.SEARCHURl)
                .addPathParameter("query", query)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(object : JSONObjectRequestListener {
                    override fun onResponse(response: JSONObject) {
                        try {
                            modelMainList.clear()
                            progressDialog?.dismiss()
                            val jsonArray = response.getJSONArray("data")
                            for (i in 0 until jsonArray.length()) {
                                val jsonObject = jsonArray.getJSONObject(i)
                                val dataApi = ModelMain()
                                dataApi.strId = jsonObject.getString("songId")
                                dataApi.strArtis = jsonObject.getString("artist").replace("· ", "")
                                dataApi.strTitle = jsonObject.getString("songTitle")
                                modelMainList.add(dataApi)
                            }
                            showRecyclerSearchResults()
                        } catch (e: JSONException) {
                            e.printStackTrace()
                            Toast.makeText(this@SearchActivity, "Gagal menampilkan hasil pencarian!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onError(anError: ANError) {
                        progressDialog?.dismiss()
                        Toast.makeText(this@SearchActivity, "Tidak ada jaringan internet!", Toast.LENGTH_SHORT).show()
                    }
                })
        }



            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    if (!query.isNullOrBlank()) {
                        setSearchSong(query)
                    }
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    // Tambahkan logika jika diperlukan ketika teks pencarian berubah
                    return false
                }
            })




        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottomNavigation)
        bottomNavigation.setOnNavigationItemSelectedListener setOnItemSelectedListener@{ item ->
            when (item.itemId) {
                R.id.menu_home -> {
                    val intent = Intent(this@SearchActivity, MainActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.menu_search -> {

                    // Jangan lakukan apa-apa jika sudah berada di halaman pencarian
                    true
                }

                R.id.menu_about -> {

                    val intent = Intent(this@SearchActivity, AboutActivity::class.java)
                    startActivity(intent)

                    // Handle click on About tab
                    // Tambahkan logika atau intent untuk membuka halaman About
                    true
                }

                else -> false
            }
        }





    }


}





