package com.azhar.mylyrics.activities

import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.azhar.mylyrics.R
import com.azhar.mylyrics.adapter.MainAdapter
import com.azhar.mylyrics.model.ModelMain
import com.azhar.mylyrics.networking.ApiEndpoint
import com.azhar.mylyrics.utils.OnItemClickCallback
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class MainActivity : AppCompatActivity() {

    var modelMainList = ArrayList<ModelMain>()
    var mainAdapter: MainAdapter? = null
    var progressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        progressDialog = ProgressDialog(this)
        progressDialog?.setTitle("Mohon Tunggu")
        progressDialog?.setCancelable(false)
        progressDialog?.setMessage("Sedang menampilkan lagu...")




        rvListMusic.layoutManager = LinearLayoutManager(this)
        rvListMusic.setHasFixedSize(true)

        getListSongTop()



        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottomNavigation)
        bottomNavigation.setOnNavigationItemSelectedListener setOnItemSelectedListener@{ item ->
            when (item.itemId) {
                R.id.menu_home -> {



                    return@setOnItemSelectedListener true


                    // Handle click on Home tab
                    // Tambahkan logika atau intent untuk membuka halaman Home
                    true
                }

                R.id.menu_search -> {
                    val intent = Intent(this@MainActivity, SearchActivity::class.java)
                    startActivity(intent)

                    // Handle click on Search tab
                    // Tambahkan logika atau intent untuk membuka halaman Search
                    true
                }

                R.id.menu_about -> {

                    val intent = Intent(this@MainActivity, AboutActivity::class.java)
                    startActivity(intent)

                    // Handle click on About tab
                    // Tambahkan logika atau intent untuk membuka halaman About
                    true
                }

                else -> false
            }
        }
    }

    // Metode getListSongTop() dan setSearchSong() tetap sama seperti sebelumnya
    private fun getListSongTop(){
        progressDialog?.show()
        progressDialog?.dismiss()
        AndroidNetworking.get(ApiEndpoint.BASEURl)
            .setPriority(Priority.HIGH)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    try {
                        progressDialog?.dismiss()
                        val jsonArray = response.getJSONArray("data")
                        for (i in 0..10) {
                            val jsonObject = jsonArray.getJSONObject(i)
                            val dataApi = ModelMain()
                            dataApi.strId = jsonObject.getString("songId")
                            dataApi.strArtis = jsonObject.getString("artist")
                            dataApi.strTitle = jsonObject.getString("songTitle")
                            modelMainList.add(dataApi)
                        }
                        showRecyclerSong()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(this@MainActivity, "Gagal menampilkan data!",
                            Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onError(anError: ANError) {
                    progressDialog?.dismiss()
                    Toast.makeText(this@MainActivity, "Tidak ada jaringan internet!",
                        Toast.LENGTH_SHORT).show()
                }
            })
    }







    private fun showRecyclerSong() {
        mainAdapter = MainAdapter(this, modelMainList)
        rvListMusic.adapter = mainAdapter
        mainAdapter?.setOnItemClickCallback(object : OnItemClickCallback {
            override fun onItemClicked(modelMain: ModelMain) {
                val intent = Intent(this@MainActivity, DetailLyricsActivity::class.java)
                intent.putExtra(DetailLyricsActivity.LIST_LYRICS, modelMain)
                startActivity(intent)
            }
        })
    }
}
