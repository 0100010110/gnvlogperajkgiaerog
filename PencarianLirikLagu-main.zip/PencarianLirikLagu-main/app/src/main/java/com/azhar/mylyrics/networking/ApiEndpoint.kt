package com.azhar.mylyrics.networking


object ApiEndpoint {
    
    var BASEURl = "http://song-lyrics-api.azharimm.dev/hot"
   
    var SEARCHURl = "http://song-lyrics-api.azharimm.dev/search?q={query}"
    
    var DETAILURl = "http://song-lyrics-api.azharimm.dev/lyrics/{id}"
}