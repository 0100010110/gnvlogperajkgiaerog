package com.azhar.mylyrics.model

import java.io.Serializable

class ModelMain : Serializable {
    var strId: String = ""
    var strArtis: String = ""
    var strTitle: String = ""
}