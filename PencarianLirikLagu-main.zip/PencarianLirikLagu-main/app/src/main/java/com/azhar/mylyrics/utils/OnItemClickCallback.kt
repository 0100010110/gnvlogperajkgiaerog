package com.azhar.mylyrics.utils

import com.azhar.mylyrics.model.ModelMain

/**
 * Created by Azhar Rivaldi on 26-02-2021
 */

interface OnItemClickCallback {
    fun onItemClicked(modelMain: ModelMain)
}